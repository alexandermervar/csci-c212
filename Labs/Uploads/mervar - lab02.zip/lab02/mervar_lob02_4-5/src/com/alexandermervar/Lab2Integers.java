//  Lab 2
//
//  Released:  1/20/20
//
//  @Author  Alexander Mervar amervar
//  Last Edited: 9.7.2021
//
//
//  Directions:  Implement the following methods
//
//
//////////////////////////////////////////////////////////////////////////////////

package com.alexandermervar;

public class Lab2Integers {

    public static char intToChar(int givenInt) {
        return (char) givenInt;
    }

    public static int charToInt(char givenChar) {
        return (int) givenChar;
    }
}
